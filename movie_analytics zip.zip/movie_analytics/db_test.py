from fastapi import FastAPI
import pyodbc

app = FastAPI(title="Movie Analytics API")

# ---- DB CONNECTION HELPER ----
def get_connection():
    return pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=DESKTOP-6HKMS9V\\MSSQL;"
        "DATABASE=MovieAnalytics;"
        "Trusted_Connection=yes;"
    )

# ---- HEALTH CHECK ----
@app.get("/")
def home():
    return {"status": "Movie Analytics API is running (SQL Server)"}

# ---- LIST MOVIES ----
@app.get("/movies")
def get_movies():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT title FROM movies")
    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return [row[0] for row in rows]

# ---- MOVIE ANALYTICS ----
@app.get("/analytics/movie")
def movie_analytics(name: str):
    conn = get_connection()
    cursor = conn.cursor()

    query = """
    SELECT 
        m.title,
        m.tmdb_rating,
        m.tmdb_votes,
        m.tmdb_popularity,
        COUNT(b.booking_id) AS total_bookings,
        SUM(b.total_amount) AS total_revenue
    FROM bookings b
    JOIN shows s ON b.show_id = s.show_id
    JOIN movies m ON s.movie_id = m.movie_id
    WHERE UPPER(b.status) = 'CONFIRMED'
      AND m.title = ?
    GROUP BY 
        m.title, m.tmdb_rating, m.tmdb_votes, m.tmdb_popularity;
    """

    cursor.execute(query, (name,))
    row = cursor.fetchone()

    if not row:
        cursor.close()
        conn.close()
        return {"message": "No data found for this movie"}

    # ---- TOP CITY QUERY ----
    city_query = """
    SELECT TOP 1
        c.city_name,
        SUM(b.total_amount) AS revenue
    FROM bookings b
    JOIN shows s ON b.show_id = s.show_id
    JOIN theatres t ON s.theatre_id = t.theatre_id
    JOIN cities c ON t.city_id = c.city_id
    JOIN movies m ON s.movie_id = m.movie_id
    WHERE m.title = ?
      AND b.status = 'CONFIRMED'
    GROUP BY c.city_name
    ORDER BY revenue DESC;
    """

    cursor.execute(city_query, (name,))
    city = cursor.fetchone()

    cursor.close()
    conn.close()

    return {
        "movie": row[0],
        "tmdb_rating": row[1],
        "tmdb_votes": row[2],
        "popularity": row[3],
        "total_bookings": row[4],
        "total_revenue": row[5],
        "top_city": city[0] if city else None
    }

@app.get("/analytics/rating-vs-revenue")
def rating_vs_revenue():
    conn = get_connection()
    cursor = conn.cursor()

    query = """
    SELECT
        m.title,
        m.tmdb_rating,
        SUM(b.total_amount) AS total_revenue,
        COUNT(b.booking_id) AS total_bookings
    FROM movies m
    JOIN shows s ON m.movie_id = s.movie_id
    JOIN bookings b ON s.show_id = b.show_id
    WHERE b.status = 'CONFIRMED'
    GROUP BY m.title, m.tmdb_rating
    ORDER BY total_revenue DESC;
    """

    cursor.execute(query)
    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return [
        {
            "movie": row[0],
            "rating": row[1],
            "revenue": row[2],
            "bookings": row[3]
        }
        for row in rows
    ]
