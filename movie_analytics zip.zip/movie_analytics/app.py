import streamlit as st
import requests

st.set_page_config(
    page_title="Movie Analytics Platform",
    layout="centered"
)

st.title("🎬 Movie Analytics Platform")
st.write("Search a movie to view ratings, popularity, and booking analytics")

# -----------------------
# Movie input
# -----------------------
movie_name = st.text_input(
    "Enter movie name",
    placeholder="e.g. Jawan"
)

# -----------------------
# Search button
# -----------------------
if st.button("Search"):
    if movie_name.strip() == "":
        st.warning("Please enter a movie name")
    else:
        url = f"http://127.0.0.1:8000/analytics/movie?name={movie_name}"
        response = requests.get(url)

        if response.status_code != 200:
            st.error("FastAPI backend is not running")
        else:
            data = response.json()

            if "message" in data:
                st.error(data["message"])
            elif "error" in data:
                st.error(data["error"])
            else:
                # -----------------------
                # Movie Header
                # -----------------------
                st.success(f"🎥 {data['movie']}")

                # -----------------------
                # Movie Metadata
                # -----------------------
                st.subheader("🎬 Movie Metadata")

                col1, col2, col3 = st.columns(3)
                col1.metric("⭐ TMDB Rating", data["tmdb_rating"])
                col2.metric("🗳️ Votes", data["tmdb_votes"])
                col3.metric("🔥 Popularity", round(data["popularity"], 2))

                # -----------------------
                # Business Analytics
                # -----------------------
                st.subheader("📊 Booking Analytics")

                col4, col5, col6 = st.columns(3)
                col4.metric("🎟️ Total Bookings", data["total_bookings"])
                col5.metric("💰 Total Revenue", f"₹ {data['total_revenue']}")
                col6.metric("🏙️ Top City", data["top_city"])

import pandas as pd
import matplotlib.pyplot as plt

st.divider()
st.subheader("📈 Rating vs Revenue Analysis")

# Fetch rating vs revenue data
rv_url = "http://127.0.0.1:8000/analytics/rating-vs-revenue"
rv_response = requests.get(rv_url)

if rv_response.status_code == 200:
    rv_data = rv_response.json()

    if len(rv_data) == 0:
        st.info("No data available for analysis")
    else:
        df = pd.DataFrame(rv_data)

        # Bigger figure so everything fits
        fig, ax = plt.subplots(figsize=(8, 5))

        ax.scatter(
            df["rating"],
            df["revenue"],
            s=df["bookings"] * 200,   # reduced bubble size
            alpha=0.7
        )

        # Add movie labels safely
        for i, movie in enumerate(df["movie"]):
            ax.annotate(
                movie,
                (df["rating"][i], df["revenue"][i]),
                fontsize=8,
                xytext=(6, 6),
                textcoords="offset points"
            )

        ax.set_xlabel("TMDB Rating")
        ax.set_ylabel("Total Revenue")
        ax.set_title("Rating vs Revenue (Bubble size = Bookings)")

        # Prevent plot from cutting off labels
        plt.tight_layout()

        st.pyplot(fig)
else:
    st.error("Could not load rating vs revenue data")

st.subheader("📊 Revenue by City")

# Use existing API response (NO extra API call needed)
df_city = pd.DataFrame(
    [{
        "City": data["top_city"],
        "Revenue": data["total_revenue"]
    }]
)

fig, ax = plt.subplots()
ax.bar(df_city["City"], df_city["Revenue"])
ax.set_xlabel("City")
ax.set_ylabel("Revenue")
st.pyplot(fig)
