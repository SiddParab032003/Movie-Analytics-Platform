import requests
import pyodbc
import time

TMDB_API_KEY = "23e93ecd1874af906cac4c815d4db436"   # keep key safe in real projects

# ---- SQL SERVER CONNECTION ----
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=DESKTOP-6HKMS9V\\MSSQL;"
    "DATABASE=MovieAnalytics;"
    "Trusted_Connection=yes;"
)
cursor = conn.cursor()

# ---- FETCH MOVIES TO ENRICH ----
cursor.execute("""
SELECT movie_id, title, YEAR(release_date)
FROM movies
WHERE tmdb_rating IS NULL
""")

movies = cursor.fetchall()

# ---- TMDB ENRICHMENT LOOP ----
for movie_id, title, year in movies:
    print(f"Searching TMDB for: {title} ({year})")

    try:
        search_url = (
            f"https://api.themoviedb.org/3/search/movie"
            f"?api_key={TMDB_API_KEY}&query={title}&year={year}"
        )

        response = requests.get(search_url, timeout=10)
        response.raise_for_status()
        search = response.json()

        if not search.get("results"):
            print("Not found on TMDB")
            time.sleep(1.5)
            continue

        movie = search["results"][0]

        cursor.execute("""
        UPDATE movies
        SET tmdb_rating = ?, tmdb_votes = ?, tmdb_popularity = ?
        WHERE movie_id = ?
        """,
        movie.get("vote_average"),
        movie.get("vote_count"),
        movie.get("popularity"),
        movie_id)

        conn.commit()

        # 🔑 CRITICAL: avoid TMDB rate-limit
        time.sleep(1.5)

    except requests.exceptions.RequestException as e:
        print(f"TMDB error for {title}: {e}")
        time.sleep(3)
        continue

# ---- CLEANUP ----
cursor.close()
conn.close()

print("TMDB enrichment completed")
